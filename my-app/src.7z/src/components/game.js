import React, { Component } from 'react';
import './start.css';
class Game extends React.Component {}
export default Game;
