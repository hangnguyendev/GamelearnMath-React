import { combineReducers } from 'redux';
import { resetNumber } from '../resetNumber';
// import visibilityFilter from './visibilityFilter';

export default combineReducers({
  resetNumber
});
